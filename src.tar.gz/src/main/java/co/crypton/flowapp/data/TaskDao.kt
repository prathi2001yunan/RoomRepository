package co.crypton.flowapp.data

import androidx.room.*
import androidx.room.Dao
import androidx.room.OnConflictStrategy
import kotlinx.coroutines.flow.Flow

import co.crypton.flowapp.model.Note

@Dao
interface NoteDao {
    @Query("SELECT * FROM Note")
    fun getNotes(): Flow<List<Note>>

    @Query("SELECT * FROM Note WHERE id = :noteId")
    fun getNoteById(noteId: Int): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertNote(note: Note)

    @Update
    fun updateNote(note: Note)

    @Delete
    fun deleteNote(note: Note)
}
