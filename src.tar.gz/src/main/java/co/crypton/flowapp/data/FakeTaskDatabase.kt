package co.crypton.flowapp.data

import co.crypton.flowapp.model.Note

object FakeNoteDatabase {
    private var Notes = mutableListOf<Note>()
    private var idCounter = 1

    fun addNote(note: Note): Note {
        // Note.id = idCounter++
        Notes.add(note)
        return note
    }

    fun updateNote(note: Note) {
        Notes.replaceAll { if (it.id == note.id) note else it }
    }

    fun deleteNote(noteId: Int) {
        Notes.removeAll { it.id == noteId }
    }

    fun getNotes(): List<Note> = Notes

    fun getNoteById(noteId: Int): Note? = Notes.find { it.id == noteId }
}
