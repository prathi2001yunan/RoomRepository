package co.crypton.flowapp

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

import co.crypton.flowapp.data.AppDatabase
import co.crypton.flowapp.data.FakeNoteDatabase
import co.crypton.flowapp.data.NoteDao
import co.crypton.flowapp.repository.NoteRepository
import co.crypton.flowapp.repository.NoteRepositoryImpl

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext appContext: Context): AppDatabase {
        return Room.databaseBuilder(
            appContext,
            AppDatabase::class.java,
            "Note-database"
        ).build()
    }

    @Provides
    fun provideNoteDao(database: AppDatabase): NoteDao {
        return database.NoteDao()
    }

    @Provides
    fun provideNoteRepository(NoteDao: NoteDao): NoteRepository = NoteRepositoryImpl(NoteDao)
}
