package co.crypton.flowapp.ui.task

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

import co.crypton.flowapp.model.Task

@Composable
fun TaskScreen(viewModel: TaskViewModel = hiltViewModel()) {
    val tasks by viewModel.tasks.collectAsState()
    var taskInput by remember { mutableStateOf("") }
    var selectedTaskId by remember { mutableStateOf<Int?>(null) }

    Column(modifier = Modifier.padding(16.dp)) {
        // Task input field
        OutlinedTextField(
            value = taskInput,
            onValueChange = { taskInput = it },
            label = { Text("Enter task") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Add/Edit button
        Button(
            onClick = {
                selectedTaskId?.let {
                    viewModel.updateTask(Task(id = it, title = taskInput, description = "", isCompleted = false))
                } ?: viewModel.addTask(Task(id = 0, title = taskInput, description = "", isCompleted = false))
                taskInput = ""
                selectedTaskId = null
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (selectedTaskId == null) "Add Task" else "Update Task")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // List of tasks
        LazyColumn {
            items(tasks) { task ->
                TaskItem(
                    task = task,
                    onDelete = { viewModel.deleteTask(task.id) },
                    onComplete = { viewModel.updateTask(task.copy(isCompleted = true)) },
                    onEdit = {
                        taskInput = task.title
                        selectedTaskId = task.id
                    }
                )
            }
        }
    }
}

@Composable
fun TaskItem(task: Task, onDelete: () -> Unit, onComplete: () -> Unit, onEdit: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = task.title, style = if (task.isCompleted) MaterialTheme.typography.titleSmall.copy(color = MaterialTheme.colorScheme.primary) else MaterialTheme.typography.titleSmall)
        Row {
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
            IconButton(onClick = onComplete) { Icon(Icons.Default.Done, contentDescription = "Complete") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
        }
    }
}
