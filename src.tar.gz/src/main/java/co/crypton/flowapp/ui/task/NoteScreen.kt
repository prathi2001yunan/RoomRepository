package co.crypton.flowapp.ui.task

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NoteScreen(viewModel: NoteViewModel, onNavigate: () -> Unit) {
    val notes by viewModel.notes.collectAsState()
    Scaffold(topBar = { }, bottomBar = { }, floatingActionButton = {
        FloatingActionButton(onClick = {
            onNavigate()
        }) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "add icon")
        }

    }, floatingActionButtonPosition = FabPosition.End
    ) { paddingValues ->
        // rest of the app's UI
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(paddingValues)
                .padding(vertical = 10.dp, horizontal = 10.dp)
        ) {
            items(notes) {
                NoteDataDisplay(
                    it.title, it.description, it.id, it.date
                ) { id -> viewModel.deleteNote(id) }
                Spacer(modifier = Modifier.size(10.dp))
            }
        }
    }
}


@Composable
fun NoteDataDisplay(
    title: String, description: String, id: Int, date: String, onDelete: (id: Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .clip(RoundedCornerShape(20.dp, 0.dp, 20.dp, 0.dp))
            .background(
                Color.LightGray, RoundedCornerShape(20.dp, 0.dp, 20.dp, 0.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(text = "Title: $title", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(0.5f))
                Text(text = date)
            }
            Spacer(modifier = Modifier.size(10.dp))
            Text(text = "Description: $description", fontSize = 15.sp, fontWeight = FontWeight.W300)
        }
        Icon(imageVector = Icons.Default.Delete, modifier = Modifier
            .size(30.dp)
            .clickable {
                onDelete(id)
            }
            .align(alignment = Alignment.BottomEnd), contentDescription = "Delete")
    }
}






