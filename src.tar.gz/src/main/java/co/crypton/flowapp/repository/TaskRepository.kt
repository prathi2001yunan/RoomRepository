package co.crypton.flowapp.repository

import kotlinx.coroutines.flow.Flow

import co.crypton.flowapp.model.Note

interface NoteRepository {
    suspend fun addNote(note: Note)
    suspend fun updateNote(note: Note)
    suspend fun deleteNote(noteId: Int)
    fun getNotesFlow(): Flow<List<Note>>
    suspend fun getNoteById(noteId: Int): Note?
}
