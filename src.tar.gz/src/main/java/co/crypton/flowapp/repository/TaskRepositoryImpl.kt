package co.crypton.flowapp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

import co.crypton.flowapp.data.FakeNoteDatabase
import co.crypton.flowapp.data.NoteDao
import co.crypton.flowapp.model.Note
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class NoteRepositoryImpl @Inject constructor(private val noteDao: NoteDao) : NoteRepository {

    override fun getNotesFlow(): Flow<List<Note>> = noteDao.getNotes()
    override suspend fun getNoteById(noteId: Int): Note? = noteDao.getNoteById(noteId)

    override suspend fun addNote(note: Note) = noteDao.insertNote(note)

    override suspend fun updateNote(note: Note) = noteDao.updateNote(note)

    override suspend fun deleteNote(noteId: Int) {
        val note = noteDao.getNoteById(noteId)
        if (note != null) {
            noteDao.deleteNote(note)
        }
    }
}

