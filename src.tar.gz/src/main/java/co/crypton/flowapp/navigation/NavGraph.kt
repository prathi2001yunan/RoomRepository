package co.crypton.flowapp.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import co.crypton.flowapp.ui.task.NoteScreen
import co.crypton.flowapp.ui.task.NoteDetailScreen
import co.crypton.flowapp.ui.task.NoteViewModel

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController(),
    viewModel: NoteViewModel = hiltViewModel()
) {
    NavHost(navController = navController, startDestination = NavRoute.NoteScreen.route) {
        composable(NavRoute.NoteScreen.route) {
            NoteScreen(viewModel) {
                navController.navigate(NavRoute.NoteDetailScreen.route)
            }
        }
        composable(NavRoute.NoteDetailScreen.route) {
            NoteDetailScreen(viewModel)
        }
    }
}
