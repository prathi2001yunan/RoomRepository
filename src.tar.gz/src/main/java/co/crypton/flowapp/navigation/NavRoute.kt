package co.crypton.flowapp.navigation

sealed class NavRoute(val route: String) {
    data object NoteScreen : NavRoute("note_screen")

    data object NoteDetailScreen : NavRoute("note_detail_screen")
}